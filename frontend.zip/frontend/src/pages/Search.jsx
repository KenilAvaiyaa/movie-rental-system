function Search() {
  return (
    <div>
      <h1>Search</h1>
      <p>Welcome to Seach page!</p>
    </div>
  );
}

export default Search;
