function UserRentedMovies() {
  return (
    <div>
      <h1>Rented Movies</h1>
      <p>Welcome to Rented Movies!</p>
    </div>
  );
}

export default UserRentedMovies;
