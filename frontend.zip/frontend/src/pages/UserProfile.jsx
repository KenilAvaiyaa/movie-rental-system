function UserProfile() {
  return (
    <div>
      <h1>User Profile</h1>
      <p>Welcome to Profile page!</p>
    </div>
  );
}

export default UserProfile;
